const projectName = 'tribute-Bolaño';
localStorage.setItem('first_project', 'Tribute to Bolaño');